
export const DB_URL = "postgres://postgres:mysecretpassword@localhost/postgres";